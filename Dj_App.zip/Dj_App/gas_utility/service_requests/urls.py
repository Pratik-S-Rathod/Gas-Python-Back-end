from django.urls import path
from . import views

urlpatterns = [
    path('', views.request_home, name='request_home'),
]
