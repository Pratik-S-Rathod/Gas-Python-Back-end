from django.shortcuts import render

def request_home(request):
    return render(request, 'service_requests/request_home.html')
